package principal;

public class Node {
    int data;
    Node next;
}